import javax.swing.JOptionPane;

public class ejercicio_7 {
    public static void main(String[] args) {
        String inputgolesliga = JOptionPane.showInputDialog("Ingresa los goles en LaLiga: ");
        String inputgolescoparey = JOptionPane.showInputDialog("Ingresa los goles en Copa del Rey: ");
        String inputgolescampeones = JOptionPane.showInputDialog("Ingresa los goles en Liga de Campeones: ");
        
        int goles_liga = Integer.parseInt(inputgolesliga);
        int goles_copa_rey = Integer.parseInt(inputgolescoparey);
        int goles_campeones = Integer.parseInt(inputgolescampeones);
        
        int totalgoles = goles_liga + goles_copa_rey + goles_campeones;
        
        JOptionPane.showMessageDialog(null, "El total de goles es: " + totalgoles);
    }
}
