goles_liga = int(input("Ingresa los goles en la liga: "))
goles_copa_rey = int(input("Ingresa los goles en copa del rey: "))
goles_campeones = int(input("Ingresa los goles en liga de campeones: "))

total_goles = goles_liga + goles_copa_rey + goles_campeones

print("El total de goles es: ", total_goles)
