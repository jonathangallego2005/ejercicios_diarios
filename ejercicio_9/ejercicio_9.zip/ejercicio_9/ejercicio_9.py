numero = int(input("Ingresa un número de 0 a 9: "))

if numero == 0:
    print("cero")
elif numero == 1:
    print("uno")
elif numero == 2:
    print("dos")
elif numero == 3:
    print("tres")
elif numero == 4:
    print("cuatro")
elif numero == 5:
    print("cinco")
elif numero == 6:
    print("seis")
elif numero == 7:
    print("siete")
elif numero == 8:
    print("ocho")
elif numero == 9:
    print("nueve")
else:
    print("El número ",numero, "esta fuera del rango de 0 a 9")








