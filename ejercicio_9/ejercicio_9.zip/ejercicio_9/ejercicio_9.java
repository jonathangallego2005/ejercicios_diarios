import java.util.Scanner;
public class ejercicio_9 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int numero;
        String resultado;

        System.out.print("Ingresa un número de 0 a 9: ");
        numero = entrada.nextInt();


        switch (numero) {
            case 0:
                resultado = "cero";
                System.out.println(resultado);
                break;
            case 1:
                resultado = "uno";
                System.out.println(resultado);
                break;
            case 2:
                resultado = "dos";
                System.out.println(resultado);
                break;
            case 3:
                resultado = "tres";
                System.out.println(resultado);
                break;
            case 4:
                resultado = "cuatro";
                System.out.println(resultado);
                break;
            case 5:
                resultado = "cinco";
                System.out.println(resultado);
                break;
            case 6:
                resultado = "seis";
                System.out.println(resultado);
                break;
            case 7:
                resultado = "siete";
                System.out.println(resultado);
                break;
            case 8:
                resultado = "ocho";
                System.out.println(resultado);
                break;
            case 9:
                resultado = "nueve";
                System.out.println(resultado);
                break;
            default:
            System.out.println("El numero "+numero+" esta fuera del rango de 0 a 9");
                
        }
        
        entrada.close();
        
    }
}

