import java.util.Scanner;
public class ejercicio_6 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String name;

        System.out.print("Ingresa tu nombre: ");
        name = entrada.nextLine();        

        if("propietario".equals(name)){
            System.out.println("Hola jefe");
        }else{
            System.out.println("Hola invitado");
        }

        entrada.close();
    }
}