name = input("Ingresa tu nombre: ")

if name == "propietario":
    print("Hola jefe")
else:
    print("Hola invitado")    