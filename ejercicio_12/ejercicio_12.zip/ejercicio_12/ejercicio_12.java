import java.util.Scanner;
public class ejercicio_12 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int cadena_input=0;
        int mayor,menor; 
        System.out.print("Ingresa cuantos numeros va ha tener tu cadena de numeros: ");
        cadena_input = entrada.nextInt();
        int [] cadena = new int[cadena_input];
        System.out.println("");

        for (int i = 0; i < cadena_input; i++ ){
            System.out.print("Ingresa el "+(i+1)+" número de la cadena: ");
            cadena[i] = entrada.nextInt();
        }
        System.out.println("Los números que ingresaste son: ");
        for (int i = 0; i < cadena_input; i++) {
            System.out.print(cadena[i] + " "); 
        }    
        System.out.println(" ");
        mayor = cadena[0];
        menor = cadena[0];
        for (int i = 1; i < cadena_input; i++) {
            if (cadena[i] > mayor) {
                mayor = cadena[i];
            }
            if (cadena[i] < menor) {
                menor = cadena[i];
            }
        }
        System.out.println("el número mayor es: "+mayor);
        System.out.println("El número menor es: "+menor);
        entrada.close();
    }
}            