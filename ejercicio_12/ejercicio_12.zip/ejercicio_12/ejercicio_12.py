cadena_input = int(input("Ingresa cuántos números va a tener tu cadena de números: "))
print("")
cadena = []

for i in range(cadena_input):
    numero = int(input(f"Ingresa el {i + 1} número de la cadena: "))
    cadena.append(numero)
print("Los números que ingresaste son:", cadena," ")
print("")
mayor = cadena[0]
menor = cadena[0]
for i in range(1, cadena_input):
    if cadena[i] > mayor:
        mayor = cadena[i]
    if cadena[i] < menor:
        menor = cadena[i]
print("El número mayor es: ", mayor)
print("El número menor es: ", menor)
