import java.util.Scanner;

public class ejercicio_8 {
    public static void main(String[] args){
        Scanner entrada = new Scanner(System.in);

        int numero,cuadrado;

        System.out.print("Ingresa un número: ");
        numero = entrada.nextInt();

        cuadrado = numero * numero;

        System.out.println("El número que ingresaste al cuadrado es: "+cuadrado);

        entrada.close();

    }
}
