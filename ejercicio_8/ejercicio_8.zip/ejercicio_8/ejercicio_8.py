numero = int(input("Ingresa un número: "))

cuadrado = numero * numero

print("El numero que ingresaste al cuadrado es: ", cuadrado)
