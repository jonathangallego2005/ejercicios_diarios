def main():
    cadena_cantidad = int(input("Ingresa cuántas palabras va a tener tu cadena de texto: "))
    cadena_textos = []
    print(" ")
    palabra_corta = ""
    for i in range(cadena_cantidad):
        palabra = input(f"Ingresa la palabra {i+1}: ")
        cadena_textos.append(palabra)
        if i == 0 or len(palabra) < len(palabra_corta):
            palabra_corta = palabra
    print(" ")
    print(f"La palabra más corta es: {palabra_corta}")
    print(" ")
    longitud = len(palabra_corta)
    print(f"Y la longitud de la palabra más corta es: {longitud}")
if __name__ == "__main__":
    main()
