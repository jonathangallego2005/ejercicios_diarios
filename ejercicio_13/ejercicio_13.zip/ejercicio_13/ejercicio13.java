import java.util.Scanner;
public class ejercicio13 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int cadena_cantidad,longitud;
        String palabra_corta="";
        System.out.print("Ingresa cuantas palabras va a tener tu cadena de texto: ");
        cadena_cantidad = entrada.nextInt();
        String[] cadena_textos = new String[cadena_cantidad];
        System.out.println(" ");
        for(int i = 0; i < cadena_cantidad; i++){
            System.out.println("Ingresa la palabra "+(i+1)+" : ");
            cadena_textos[i] = entrada.next();
            if (i == 0 || cadena_textos[i].length() < palabra_corta.length()) {
                palabra_corta = cadena_textos[i];
            }
        }
        System.out.println(" ");
        System.out.println("La palabra mas corta es: "+palabra_corta);
        System.out.println(" ");
        longitud = palabra_corta.length();
        System.out.println("Y la longitud de la palabra mas corta es: " + longitud);

        entrada.close();
    }
}            