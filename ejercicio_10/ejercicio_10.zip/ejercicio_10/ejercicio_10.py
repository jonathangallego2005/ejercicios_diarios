numero = int(input("Ingresa un número: "))
cambiaso = -numero
print(cambiaso)
