import java.util.Scanner;
public class ejercicio_10 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int numero,cambiaso;

        System.out.print("Ingresa un número: ");
        numero = entrada.nextInt();

        cambiaso = -numero;
        System.out.println(cambiaso);
        
        entrada.close();
    }
}