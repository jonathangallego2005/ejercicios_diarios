numeros = [0] * 5  

numeros[0] = int(input("Ingresa el número 1: "))
numeros[1] = int(input("Ingresa el número 2: "))
numeros[2] = int(input("Ingresa el número 3: "))
numeros[3] = int(input("Ingresa el número 4: "))
numeros[4] = int(input("Ingresa el número 5: "))

print("Los números que ingresaste son: ",numeros)

cuadrado = [numeros[0]*numeros[0],numeros[1]*numeros[1],numeros[2]*numeros[2],numeros[3]*numeros[3],numeros[4]*numeros[4]]
print("Los números que ingresaste uno por uno al cuadrado son: ",cuadrado)

 


