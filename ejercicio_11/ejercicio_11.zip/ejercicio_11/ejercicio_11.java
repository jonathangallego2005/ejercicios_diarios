import java.util.Scanner;
public class ejercicio_11 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int union_u;
        int concatenar_u;
        String resultado_u,cuadrado_u;
        int[] numeros = new int[5];
        
        for(int i = 0; i < numeros.length; i++){
            System.out.print("Ingresa el número "+(i+1)+": ");
            numeros[i] = entrada.nextInt();
        }

        resultado_u = Integer.toString(numeros[0]) + Integer.toString(+numeros[1])+ Integer.toString(numeros[2])
        + Integer.toString(numeros[3])+Integer.toString(numeros[4]);
        concatenar_u = Integer.parseInt(resultado_u);
        System.out.println("Los números que ingresaste son: "+concatenar_u);

        cuadrado_u = Integer.toString(numeros[0]*numeros[0]) + Integer.toString(numeros[1]*numeros[1])+ Integer.toString(numeros[2]*numeros[2])
        + Integer.toString(numeros[3]*numeros[3])+ Integer.toString(numeros[4]*numeros[4]);
        union_u = Integer.parseInt(cuadrado_u);
        System.out.println("Los números que ingresaste uno por uno al cuadrado son: "+union_u);


        entrada.close();
    }
}
